/**
 * sequence.animationFallback
 */
