# Change Log

## 2.1.0 (2015/08/27)

- Added [`reverseTimingFunctionWhenNavigatingBackwards`](http://www.sequencejs.com/documentation/#reversetimingfunctionwhennavigatingbackwards) option. `false` by default.

## 2.0.0 (2015/08/09)

- Built from ground-up
